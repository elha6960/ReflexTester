/*
 * Button_Driver.h
 *
 *  Created on: Sep 26, 2023
 *      Author: eliasharo
 */
//port a pin0
#ifndef BUTTON_DRIVER_H_
#define BUTTON_DRIVER_H_

#include <stdbool.h>
#include "stm32f4xx_hal.h"
#include "InterruptControl.h"


#define BUTTON_PORT_VALUE GPIOA //GPIO_A
#define BUTTON_PIN_NUMBER GPIO_PIN_0
#define BUTTON_PRESSED 1
#define BUTTON_NOT_PRESSED 0

void init_Button();
void enable_Clock();
bool button_Press_State();
void initButtonInterrupt();
#endif /* BUTTON_DRIVER_H_ */
