/*
 * ErrorHandlingFileset.h
 *
 *  Created on: Nov 7, 2023
 *      Author: eliasharo
 */

#ifndef INC_ERRORHANDLINGFILESET_H_
#define INC_ERRORHANDLINGFILESET_H_

#include "stdbool.h"

void APPLICATIONASSERT(bool assert);


#endif /* INC_ERRORHANDLINGFILESET_H_ */
