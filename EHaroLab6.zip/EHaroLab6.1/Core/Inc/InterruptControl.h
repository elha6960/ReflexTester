/*
 * InterruptControl.h
 *
 *  Created on: Oct 4, 2023
 *      Author: eliasharo
 */

#ifndef INTERRUPTCONTROL_H_ //check
#define INTERRUPTCONTROL_H_

#include "stm32f429xx.h"

#define EXTI0_IRQ_NUMBER 6
/* INTERRUPTCONTROL_H_ */


#define NVIC_ISER0 ((volatile uint32_t*)0xE000E100)
#define NVIC_ISER1 ((volatile uint32_t*)0xE000E104)
#define NVIC_ICER0 ((volatile uint32_t*)0xE000E180)
#define NVIC_ISPR0 ((volatile uint32_t*)0xE000E200)
#define NVIC_ICPR0 ((volatile uint32_t*)0xE000E280)
//#define APB2_BASE_ADDR 0x40010000
//#define SYSCFG_ADDR (APB2_BASE_ADDR + 0x3800)
//#define EXTI_ADDR (APB2_BASE_ADDR +0x3C00)
//#define SYSCFG ((SYSCFG_RegDef_t*) SYSCFG_ADDR)
//#define EXTI ((EXTI_RegDef_t*) EXTI_ADDR)

void IRQ_Enable_Int(uint8_t IRQ_Number);
void IRQ_Disable_Int(uint8_t IRQ_Number);
void IRQ_Clear_Pending_Int(uint8_t IRQ_Number);
void IRQ_Set_Pending_Int(uint8_t IRQ_Number);
void EXTI_Clear_Int(uint8_t pin_number);
#endif
