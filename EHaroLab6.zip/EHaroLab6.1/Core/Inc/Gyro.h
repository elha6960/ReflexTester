/*
 * Gyro.h
 *
 *  Created on: Nov 7, 2023
 *      Author: eliasharo
 */

#ifndef INC_GYRO_H_
#define INC_GYRO_H_




#include <stdio.h>
extern void initialise_monitor_handles(void);

#include "stm32f4xx_hal.h"

#define reserved1 0x00-E0
#define WHO_AM_I 0x0F
#define reserved2 0x10-1F
#define CTRL_REG1 0x20
#define CTRL_REG2 0x21
#define CTRL_REG3 0x22
#define CTRL_REG4 0x23
#define CTRL_REG5 0x24
#define REFERENCEDATACAPTURE 0x25
#define OUT_TEMP 0x26
#define STATUS_REG 0x27
#define OUT_X_L 0x28
#define OUT_X_H 0x29
#define OUT_Y_L 0x2A
#define OUT_Y_H 0x2B
#define OUT_Z_L 0x2C
#define OUT_Z_H 0x2D
#define FIFO_CTRL_REG 0x2E
#define FIFO_SRC_REG 0x2F
#define INT1_CFG 0x30
#define INT1_SRC 0x31
#define INT1_THS_XH 0x32
#define INT1_THS_XL 0x33
#define INT1_THS_YH 0x34
#define INT1_THS_YL 0x35
#define INT1_THS_ZH 0x36
#define INT1_THS_ZL 0x37
#define INT1_DURATION 0x38

#define SPI5_PORT GPIOF //check
#define NCS_MEMS_SPI GPIOC
#define NCS_MEMS_SP1 GPIO_PIN_1
#define SPI5SCK GPIO_PIN_7
#define SPI5MISO GPIO_PIN_8
#define SPI5MOSI GPIO_PIN_9

#define I3G4250D_READ (1<<7)
#define WRITE (0<<7)



void GYRO_init();
void GYRO_deviceID();
void GYRO_power();
void GYRO_reboot();
void GYRO_temp();
void GYRO_configreg();
void GYRO_verifyHALstatus();
void GYRO_enableslave();
void GYRO_disableslave();
void GYRO_axis();

#endif /* INC_GYRO_H_ */
