/*
 * Game_Driver.h
 *
 *  Created on: Nov 30, 2023
 *      Author: eliasharo
 */

#ifndef INC_GAME_DRIVER_H_
#define INC_GAME_DRIVER_H_

#include "RNG.h"
#include "LCD_Driver.h"
#include "Button_Driver.h"

void introScreen();

void Level_1();

void Level_2();

void Level_3();



void Results_screen();


void EXTI0_IRQHandler();

void resultsScreen();
#endif /* INC_GAME_DRIVER_H_ */
