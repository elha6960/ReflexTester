/*
 * ApplicationCode.h
 *
 *  Created on: Nov 14, 2023
 *      Author: xcowa
 */

#ifndef INC_APPLICATIONCODE_H_
#define INC_APPLICATIONCODE_H_



#include "Game_Driver.h"
#include "Scheduler.h"



void ApplicationInit(void);
void intro();
void firstlev();
void secondlev();
void thirdlev();
void results();
void RunDemoForLCD(void);

#endif /* INC_APPLICATIONCODE_H_ */
