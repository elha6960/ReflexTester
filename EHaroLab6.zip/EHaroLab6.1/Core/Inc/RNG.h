/*
 * RNG.h
 *
 *  Created on: Nov 28, 2023
 *      Author: eliasharo
 */

#ifndef INC_RNG_H_
#define INC_RNG_H_
#include "stdint.h"
#include "stm32f4xx_hal.h"



void RNG_init();

uint32_t RNG_recieve();



#endif /* INC_RNG_H_ */
