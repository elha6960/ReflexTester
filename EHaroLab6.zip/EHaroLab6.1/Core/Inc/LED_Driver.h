/*
 * LED_Driver.h
 *
 *  Created on: Sep 7, 2023
 *      Author: eliasharo
 */

#ifndef LED_DRIVER_H_
#define LED_DRIVER_H_

//#include <stdio.h>
//#include <stdint.h>
#include "stm32f4xx_hal.h"

#define GREEN 1
#define RED 0

void init_LED(uint8_t led);

//void clock_LED(uint8_t led);

void enable_LED(uint8_t led);

void disable_LED(uint8_t led);

void tog_LED(uint8_t led);

void enableClock(uint8_t led);
#endif /* LED_DRIVER_H_ */
