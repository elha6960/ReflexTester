/*
 * Scheduler.h
 *
 *  Created on: Sep 7, 2023
 *      Author: eliasharo
 */

#ifndef SCHEDULER_H_
#define SCHEDULER_H_

//#include <stdio.h>
#include <stdint.h>
#include "Button_Driver.h"

#define INTRO_EVENT (1<<0)
#define FIRST_EVENT (1<<1)
#define SECOND_EVENT (1<<2)
#define THIRD_EVENT (1<<3)
#define FINAL_EVENT (1<<4)


uint32_t getScheduledEvents();

void addSchedulerEvent(uint32_t event);

void removeSchedulerEvent(uint32_t remEvent);


#endif /* SCHEDULER_H_ */
