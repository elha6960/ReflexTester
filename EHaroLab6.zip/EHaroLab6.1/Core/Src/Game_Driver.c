/*
 * Game_Driver.c
 *
 *  Created on: Nov 30, 2023
 *      Author: eliasharo
 */

#include "stdlib.h"
#include "Game_Driver.h"


uint32_t getFinalTime;
uint32_t getFinalTime2;
uint32_t getFinalTime3;

static uint32_t flag;
static uint32_t flag2;
uint32_t flagbackup=0;

uint32_t finalLevel1Time;
uint32_t finalLevel2Time;
uint32_t finalLevel3Time;
uint32_t finalLevel3Time2;
uint32_t finalLevel3Time3;
uint32_t averageTime;

void introScreen()
{
	LCD_Draw_Triangle_Fill(125,150,80,LCD_COLOR_MAGENTA);
		HAL_Delay(1000);

	LCD_Draw_Circle_Fill(125,150,80,LCD_COLOR_MAGENTA);
	HAL_Delay(1000);

	LCD_Draw_Square_Fill(125,150,80,LCD_COLOR_RED);
	HAL_Delay(1000);

	LCD_Clear(0, LCD_COLOR_MAGENTA);


	LCD_SetTextColor(LCD_COLOR_BLACK);
		LCD_SetFont(&Font16x24);
	LCD_DisplayChar(80,140,'W');
		LCD_DisplayChar(95,140,'e');
		LCD_DisplayChar(110,140,'l');
		LCD_DisplayChar(125,140,'c');
		LCD_DisplayChar(140,140,'o');
		LCD_DisplayChar(155,140,'m');
		LCD_DisplayChar(170,140,'e');

		LCD_DisplayChar(95,160,'T');
		LCD_DisplayChar(110,160,'o');
		HAL_Delay(1500);
		LCD_Clear(0, LCD_COLOR_BLUE);

		LCD_DisplayChar(95,120,'T');
		LCD_DisplayChar(110,120,'h');
		LCD_DisplayChar(125,120,'e');

		LCD_DisplayChar(75,140,'R');
		LCD_DisplayChar(90,140,'E');
		LCD_DisplayChar(105,140,'F');
		LCD_DisplayChar(120,140,'L');
		LCD_DisplayChar(135,140,'E');
		LCD_DisplayChar(150,140,'X');

		LCD_DisplayChar(75,160,'T');
		LCD_DisplayChar(90,160,'E');
		LCD_DisplayChar(105,160,'S');
		LCD_DisplayChar(120,160,'T');
		LCD_DisplayChar(135,160,'E');
		LCD_DisplayChar(150,160,'R');
		HAL_Delay(2500);






}

void Level_1()
{
	int storeNum= RNG_recieve();
	LCD_Clear(0, LCD_COLOR_GREEN);
	LCD_DisplayChar(75,80,'L');
	LCD_DisplayChar(90,80,'E');
	LCD_DisplayChar(105,80,'V');
	LCD_DisplayChar(120,80,'E');
	LCD_DisplayChar(135,80,'L');
	LCD_DisplayChar(150,80,':');
	LCD_DisplayChar(165,80,'1');

			LCD_DisplayChar(60,100,'P');
			LCD_DisplayChar(75,100,'r');
			LCD_DisplayChar(90,100,'e');
			LCD_DisplayChar(105,100,'s');
			LCD_DisplayChar(120,100,'s');

			LCD_DisplayChar(150,100,'t');
			LCD_DisplayChar(165,100,'h');
			LCD_DisplayChar(180,100,'e');

			LCD_DisplayChar(45,120,'b');
			LCD_DisplayChar(60,120,'u');
			LCD_DisplayChar(75,120,'t');
			LCD_DisplayChar(90,120,'t');
			LCD_DisplayChar(105,120,'o');
			LCD_DisplayChar(120,120,'n');

			LCD_DisplayChar(150,120,'w');
			LCD_DisplayChar(165,120,'h');
			LCD_DisplayChar(180,120,'e');
			LCD_DisplayChar(195,120,'n');

			LCD_DisplayChar(60,140,'t');
			LCD_DisplayChar(75,140,'h');
			LCD_DisplayChar(90,140,'e');

			LCD_DisplayChar(120,140,'s');
			LCD_DisplayChar(135,140,'h');
			LCD_DisplayChar(150,140,'a');
			LCD_DisplayChar(165,140,'p');
			LCD_DisplayChar(180,140,'e');

			LCD_DisplayChar(75,160,'a');
			LCD_DisplayChar(90,160,'p');
			LCD_DisplayChar(105,160,'p');
			LCD_DisplayChar(120,160,'e');
			LCD_DisplayChar(135,160,'a');
			LCD_DisplayChar(150,160,'r');
			LCD_DisplayChar(165,160,'s');

			HAL_Delay(2500);
			LCD_Clear(0, LCD_COLOR_GREEN);
			uint32_t starttime;
			if(storeNum<33){
				HAL_Delay(2500);
				LCD_Draw_Circle_Fill(125,150,80,LCD_COLOR_MAGENTA);
				starttime= HAL_GetTick();

			}
			if (storeNum>33 && storeNum<66){
				HAL_Delay(2500);
				LCD_Draw_Square_Fill(125,150,80,LCD_COLOR_RED);
				 starttime= HAL_GetTick();

			}
			if (storeNum>66)
			{
				HAL_Delay(2500);
				LCD_Draw_Triangle_Fill(125,150,80,LCD_COLOR_MAGENTA);
				 starttime= HAL_GetTick();

			}

			while (flag==0){

			}

			finalLevel1Time=(getFinalTime)-starttime;

//			flag=0;



}

void Level_2()
{
	HAL_GetTick();
	flag=0;
	int storeNum= RNG_recieve();
		LCD_Clear(0, LCD_COLOR_GREEN);
		LCD_DisplayChar(75,80,'L');
		LCD_DisplayChar(90,80,'E');
		LCD_DisplayChar(105,80,'V');
		LCD_DisplayChar(120,80,'E');
		LCD_DisplayChar(135,80,'L');
		LCD_DisplayChar(150,80,':');
		LCD_DisplayChar(165,80,'2');

		LCD_DisplayChar(60,100,'P');
		LCD_DisplayChar(75,100,'r');
		LCD_DisplayChar(90,100,'e');
		LCD_DisplayChar(105,100,'s');
		LCD_DisplayChar(120,100,'s');

		LCD_DisplayChar(150,100,'t');
		LCD_DisplayChar(165,100,'h');
		LCD_DisplayChar(180,100,'e');

		LCD_DisplayChar(45,120,'b');
		LCD_DisplayChar(60,120,'u');
		LCD_DisplayChar(75,120,'t');
		LCD_DisplayChar(90,120,'t');
		LCD_DisplayChar(105,120,'o');
		LCD_DisplayChar(120,120,'n');

		LCD_DisplayChar(150,120,'w');
		LCD_DisplayChar(165,120,'h');
		LCD_DisplayChar(180,120,'e');
		LCD_DisplayChar(195,120,'n');

		LCD_DisplayChar(60,140,'t');
		LCD_DisplayChar(75,140,'h');
		LCD_DisplayChar(90,140,'e');

		LCD_DisplayChar(120,140,'s');
		LCD_DisplayChar(135,140,'h');
		LCD_DisplayChar(150,140,'a');
		LCD_DisplayChar(165,140,'p');
		LCD_DisplayChar(180,140,'e');

		LCD_DisplayChar(75,160,'a');
		LCD_DisplayChar(90,160,'p');
		LCD_DisplayChar(105,160,'p');
		LCD_DisplayChar(120,160,'e');
		LCD_DisplayChar(135,160,'a');
		LCD_DisplayChar(150,160,'r');
		LCD_DisplayChar(165,160,'s');

		LCD_DisplayChar(45,180,'i');
		LCD_DisplayChar(60,180,'n');

		LCD_DisplayChar(90,180,'t');
		LCD_DisplayChar(105,180,'o');
		LCD_DisplayChar(120,180,'p');

		LCD_DisplayChar(150,180,'r');
		LCD_DisplayChar(165,180,'i');
		LCD_DisplayChar(180,180,'g');
		LCD_DisplayChar(195,180,'h');
		LCD_DisplayChar(210,180,'t');

		LCD_DisplayChar(75,200,'c');
		LCD_DisplayChar(90,200,'o');
		LCD_DisplayChar(105,200,'r');
		LCD_DisplayChar(120,200,'n');
		LCD_DisplayChar(135,200,'e');
		LCD_DisplayChar(150,200,'r');

		HAL_Delay(5000);
		LCD_Clear(0, LCD_COLOR_BLUE);

		LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
		LCD_Draw_Horizontal_Line(0,160,240,LCD_COLOR_BLACK);
		uint32_t starttime2;
		getFinalTime=0;
		flag=0;
		while (flag==0){
			 storeNum= RNG_recieve();
			if(storeNum<25)
					{
						HAL_Delay(1000);
						LCD_Draw_Circle_Fill(60,250,40,LCD_COLOR_MAGENTA);
						HAL_Delay(1000);
						LCD_Clear(0, LCD_COLOR_BLUE);
						LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
						LCD_Draw_Horizontal_Line(0,160,240,LCD_COLOR_BLACK);
						//starttime= HAL_GetTick();

					}
					if (storeNum>25 && storeNum<50){
						HAL_Delay(1000);
						LCD_Draw_Square_Fill(180,70,40,LCD_COLOR_RED);

						 starttime2= HAL_GetTick();
						 HAL_Delay(1000);
						 LCD_Clear(0, LCD_COLOR_BLUE);
						 LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
						 LCD_Draw_Horizontal_Line(0,160,240,LCD_COLOR_BLACK);

					}
					if (storeNum>50 && storeNum<75)
					{
						HAL_Delay(1000);
						LCD_Draw_Triangle_Fill(180,225,80,LCD_COLOR_GREEN);
						HAL_Delay(1000);
						LCD_Clear(0, LCD_COLOR_BLUE);
						LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
						LCD_Draw_Horizontal_Line(0,160,240,LCD_COLOR_BLACK);
						// starttime= HAL_GetTick();

					}
					if(storeNum>75)
					{
						HAL_Delay(1000);
						LCD_Draw_Triangle_Fill(40,25,80,LCD_COLOR_GREEN);
						HAL_Delay(1000);
						LCD_Clear(0, LCD_COLOR_BLUE);
						LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
						LCD_Draw_Horizontal_Line(0,160,240,LCD_COLOR_BLACK);
					}
		}
		uint32_t finalTime2;
		finalTime2=getFinalTime2;
		finalLevel2Time=finalTime2-starttime2;
		if (storeNum >25 && storeNum<50){
			LCD_Clear(0, LCD_COLOR_BLUE);
		}else{
//			while(1){
//				LCD_Clear(0, LCD_COLOR_RED);
//			}
			finalLevel2Time=0;
		}
//		LCD_Clear(0, LCD_COLOR_BLUE);

}

void Level_3()
{
	int x;
	x=120;
	uint32_t starttime3;
	uint32_t starttime3_2;
	uint32_t starttime3_3;
	uint8_t radius=30;
	uint8_t left=1;
	uint8_t right=0;
	//uint32_t starttime2;


	LCD_Clear(0, LCD_COLOR_GREEN);
	LCD_DisplayChar(75,80,'L');
	LCD_DisplayChar(90,80,'E');
	LCD_DisplayChar(105,80,'V');
	LCD_DisplayChar(120,80,'E');
	LCD_DisplayChar(135,80,'L');
	LCD_DisplayChar(150,80,':');
	LCD_DisplayChar(165,80,'3');

	LCD_DisplayChar(60,100,'P');
	LCD_DisplayChar(75,100,'r');
	LCD_DisplayChar(90,100,'e');
	LCD_DisplayChar(105,100,'s');
	LCD_DisplayChar(120,100,'s');

	LCD_DisplayChar(150,100,'t');
	LCD_DisplayChar(165,100,'h');
	LCD_DisplayChar(180,100,'e');

	LCD_DisplayChar(45,120,'b');
	LCD_DisplayChar(60,120,'u');
	LCD_DisplayChar(75,120,'t');
	LCD_DisplayChar(90,120,'t');
	LCD_DisplayChar(105,120,'o');
	LCD_DisplayChar(120,120,'n');

	LCD_DisplayChar(150,120,'w');
	LCD_DisplayChar(165,120,'h');
	LCD_DisplayChar(180,120,'e');
	LCD_DisplayChar(195,120,'n');

	LCD_DisplayChar(60,140,'t');
	LCD_DisplayChar(75,140,'h');
	LCD_DisplayChar(90,140,'e');

	LCD_DisplayChar(120,140,'C');
	LCD_DisplayChar(135,140,'I');
	LCD_DisplayChar(150,140,'R');
	LCD_DisplayChar(165,140,'C');
	LCD_DisplayChar(180,140,'L');
	LCD_DisplayChar(195,140,'E');

	LCD_DisplayChar(75,160,'c');
	LCD_DisplayChar(90,160,'r');
	LCD_DisplayChar(105,160,'o');
	LCD_DisplayChar(120,160,'s');
	LCD_DisplayChar(135,160,'s');
	LCD_DisplayChar(150,160,'e');
	LCD_DisplayChar(165,160,'s');

	LCD_DisplayChar(195,160,'t');
	LCD_DisplayChar(210,160,'h');
	LCD_DisplayChar(225,160,'e');

	LCD_DisplayChar(120,180,'l');
	LCD_DisplayChar(135,180,'i');
	LCD_DisplayChar(150,180,'n');
	LCD_DisplayChar(165,180,'e');

	HAL_Delay(5000);
	LCD_Clear(0, LCD_COLOR_BLUE);


	flag=0;
	while(flag==0){
		LCD_Clear(0, LCD_COLOR_BLUE);
		LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
		LCD_Draw_Circle_Fill(x,160,radius,LCD_COLOR_MAGENTA);
		HAL_Delay(50);
		if (left==1)
		{
			if(x>radius)
			{
				x-=2;

			}
			else
			{
				right=1;
				left=0;
				x+=2;

			}
		}else if(right==1){
			if(x<LCD_PIXEL_WIDTH-radius){
				x+=2;
				if(x>150)
				{
				 starttime3= HAL_GetTick();
				}
			}else{
				left=1;
				right=0;
				x+=2;
			}
		}
	}

	if(x>=150) // and if right=1
	{

//		finalLevel3Time=getFinalTime2;
		finalLevel3Time=(getFinalTime+1000)-starttime3;
		LCD_Clear(0, LCD_COLOR_GREY );

	}
	else
	{
		while(1){
		LCD_Clear(0, LCD_COLOR_RED);
	}
	}

	LCD_Clear(0, LCD_COLOR_BLUE);
	HAL_Delay(100);



	flag=0;
	while(flag==0){
		LCD_Clear(0, LCD_COLOR_BLUE);
		LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
		LCD_Draw_Circle_Fill(x,160,radius,LCD_COLOR_MAGENTA);
		HAL_Delay(50);
		if (left==1)
		{
			if(x>radius)
			{
				x-=2;
				if(x<=90)
									{
									 starttime3_2= HAL_GetTick();
									}
			}
			else
			{
				right=1;
				left=0;
				x+=2;

			}
		}else if(right==1){
			if(x<LCD_PIXEL_WIDTH-radius){
				x+=2;
//				if(x>150)
//				{
//				 starttime3= HAL_GetTick();
//				}
			}else{
				left=1;
				right=0;
				x+=2;
			}
		}
	}

	if(x<=90) // and if right=1
	{

//		finalLevel3Time=getFinalTime2;
		finalLevel3Time2=(getFinalTime+1000)-starttime3_2;
		LCD_Clear(0, LCD_COLOR_GREY );

	}
	else
		{
			while(1){
			LCD_Clear(0, LCD_COLOR_RED);
		}
		}

	LCD_Clear(0, LCD_COLOR_BLUE);
	HAL_Delay(100);
	flag=0;
		while(flag==0){
			LCD_Clear(0, LCD_COLOR_BLUE);
			LCD_Draw_Vertical_Line(120,0,320,LCD_COLOR_BLACK);
			LCD_Draw_Circle_Fill(x,160,radius,LCD_COLOR_MAGENTA);
			HAL_Delay(50);
			if (left==1)
			{
				if(x>radius)
				{
					x-=2;

				}
				else
				{
					right=1;
					left=0;
					x+=2;

				}
			}else if(right==1){
				if(x<LCD_PIXEL_WIDTH-radius){
					x+=2;
					if(x>150)
					{
					 starttime3_3= HAL_GetTick();
					}
				}else{
					left=1;
					right=0;
					x+=2;
				}
			}
		}
		if(x>=150) // and if right=1
			{

		//		finalLevel3Time=getFinalTime2;
				finalLevel3Time3=(getFinalTime+1000)-starttime3_3;
				LCD_Clear(0, LCD_COLOR_GREY );

			}
			else
				{
					while(1){
					LCD_Clear(0, LCD_COLOR_RED);
				}
				}


		averageTime=(finalLevel3Time+ finalLevel3Time2+finalLevel3Time3)/3;










}



void resultsScreen()
{



	LCD_DisplayChar(50,20,'R');
	LCD_DisplayChar(65,20,'E');
	LCD_DisplayChar(80,20,'S');
	LCD_DisplayChar(95,20,'U');
	LCD_DisplayChar(110,20,'L');
	LCD_DisplayChar(125,20,'T');
	LCD_DisplayChar(140,20,'S');
	LCD_DisplayChar(155,20,'!');
	LCD_DisplayChar(170,20,'(');
	LCD_DisplayChar(185,20,'m');
	LCD_DisplayChar(200,20,'s');
	LCD_DisplayChar(215,20,')');
	HAL_Delay(2500);



	LCD_DisplayChar(5,60,'L');
	LCD_DisplayChar(20,60,'E');
	LCD_DisplayChar(35,60,'V');
	LCD_DisplayChar(50,60,'E');
	LCD_DisplayChar(65,60,'L');
	LCD_DisplayChar(80,60,'1');
	LCD_DisplayChar(95,60,':');

	LCD_DisplayChar(5,120,'L');
	LCD_DisplayChar(20,120,'E');
	LCD_DisplayChar(35,120,'V');
	LCD_DisplayChar(50,120,'E');
	LCD_DisplayChar(65,120,'L');
	LCD_DisplayChar(80,120,'2');
	LCD_DisplayChar(95,120,':');

	LCD_DisplayChar(5,180,'L');
	LCD_DisplayChar(20,180,'E');
	LCD_DisplayChar(35,180,'V');
	LCD_DisplayChar(50,180,'E');
	LCD_DisplayChar(65,180,'L');
	LCD_DisplayChar(80,180,'3');
	LCD_DisplayChar(95,180,':');

	LCD_DisplayChar(5,200,'F');
	LCD_DisplayChar(20,200,'A');
	LCD_DisplayChar(35,200,'S');
	LCD_DisplayChar(50,200,'T');
	LCD_DisplayChar(65,200,'E');
	LCD_DisplayChar(80,200,'S');
	LCD_DisplayChar(95,200,'T');
	LCD_DisplayChar(110,200,':');

	LCD_DisplayChar(5,220,'A');
	LCD_DisplayChar(20,220,'V');
	LCD_DisplayChar(35,220,'E');
	LCD_DisplayChar(50,220,'R');
	LCD_DisplayChar(65,220,'A');
	LCD_DisplayChar(80,220,'G');
	LCD_DisplayChar(95,220,'E');
	LCD_DisplayChar(110,220,':');



		char buf[20];

		itoa(finalLevel1Time,buf,10);
		if(finalLevel1Time<1000){
			LCD_DisplayChar(110,60,buf[0]);
			LCD_DisplayChar(125,60,buf[1]);
			LCD_DisplayChar(140,60,buf[2]);
		}
		if(finalLevel1Time>=1000 && finalLevel1Time<10000 )
		{
			LCD_DisplayChar(110,60,buf[0]);
			LCD_DisplayChar(125,60,buf[1]);
			LCD_DisplayChar(140,60,buf[2]);
			LCD_DisplayChar(155,60,buf[3]);
		}
		if(finalLevel1Time>=10000 )
		{
			LCD_DisplayChar(110,60,buf[0]);
			LCD_DisplayChar(125,60,buf[1]);
			LCD_DisplayChar(140,60,buf[2]);
			LCD_DisplayChar(155,60,buf[3]);
			LCD_DisplayChar(170,60,buf[4]);
		}
		itoa(finalLevel2Time,buf,10);

		if(finalLevel2Time==0){
			LCD_DisplayChar(110,120,'L');
			LCD_DisplayChar(125,120,'O');
			LCD_DisplayChar(140,120,'S');
			LCD_DisplayChar(155,120,'E');
			LCD_DisplayChar(170,120,'R');
		}


		if(finalLevel2Time<1000 && finalLevel2Time>0)
		{
			LCD_DisplayChar(110,120,buf[0]);
					LCD_DisplayChar(125,120,buf[1]);
					LCD_DisplayChar(140,120,buf[2]);
		}
		if(finalLevel2Time>=1000 && finalLevel2Time<10000)
		{
			LCD_DisplayChar(110,120,buf[0]);
			LCD_DisplayChar(125,120,buf[1]);
			LCD_DisplayChar(140,120,buf[2]);
			LCD_DisplayChar(155,120,buf[3]);
		}
		if(finalLevel2Time>=10000)
		{
			LCD_DisplayChar(110,120,buf[0]);
			LCD_DisplayChar(125,120,buf[1]);
			LCD_DisplayChar(140,120,buf[2]);
			LCD_DisplayChar(155,120,buf[3]);
			LCD_DisplayChar(170,120,buf[4]);
		}
		itoa(finalLevel3Time,buf,10);
		if(finalLevel3Time<1000)
				{
			LCD_DisplayChar(125,180,buf[0]);
						LCD_DisplayChar(140,180,buf[1]);
						LCD_DisplayChar(155,180,buf[2]);
				}
				if(finalLevel3Time>=1000 && finalLevel3Time<10000)
				{
					LCD_DisplayChar(125,180,buf[0]);
								LCD_DisplayChar(140,180,buf[1]);
								LCD_DisplayChar(155,180,buf[2]);
								LCD_DisplayChar(170,180,buf[3]);
				}
				if(finalLevel3Time>=10000)
				{
					LCD_DisplayChar(125,180,buf[0]);
									LCD_DisplayChar(140,180,buf[1]);
									LCD_DisplayChar(155,180,buf[2]);
									LCD_DisplayChar(170,180,buf[3]);
									LCD_DisplayChar(185,180,buf[4]);
				}

				itoa(averageTime,buf,10);

				if(averageTime<1000)
								{
							LCD_DisplayChar(125,220,buf[0]);
										LCD_DisplayChar(140,220,buf[1]);
										LCD_DisplayChar(155,220,buf[2]);
								}
								if(averageTime>=1000 && averageTime<10000)
								{
									LCD_DisplayChar(125,180,buf[0]);
												LCD_DisplayChar(140,220,buf[1]);
												LCD_DisplayChar(155,220,buf[2]);
												LCD_DisplayChar(170,220,buf[3]);
								}
								if(averageTime>=10000)
								{
									LCD_DisplayChar(125,180,buf[0]);
													LCD_DisplayChar(140,220,buf[1]);
													LCD_DisplayChar(155,220,buf[2]);
													LCD_DisplayChar(170,220,buf[3]);
													LCD_DisplayChar(185,220,buf[4]);
								}






				if(finalLevel3Time<=finalLevel3Time2 && finalLevel3Time<=finalLevel3Time3 )
				{
					itoa(finalLevel3Time,buf,10);
					if(finalLevel3Time<1000)
									{
								LCD_DisplayChar(125,200,buf[0]);
											LCD_DisplayChar(140,200,buf[1]);
											LCD_DisplayChar(155,200,buf[2]);
									}
									if(finalLevel3Time>=1000 && finalLevel3Time<10000)
									{
										LCD_DisplayChar(125,200,buf[0]);
													LCD_DisplayChar(140,200,buf[1]);
													LCD_DisplayChar(155,200,buf[2]);
													LCD_DisplayChar(170,200,buf[3]);
									}
									if(finalLevel3Time>=10000)
									{
										LCD_DisplayChar(125,200,buf[0]);
														LCD_DisplayChar(140,200,buf[1]);
														LCD_DisplayChar(155,200,buf[2]);
														LCD_DisplayChar(170,200,buf[3]);
														LCD_DisplayChar(185,200,buf[4]);
									}

				}
				if(finalLevel3Time2<=finalLevel3Time && finalLevel3Time2<=finalLevel3Time3 )
							{
					itoa(finalLevel3Time2,buf,10);
								if(finalLevel3Time2<1000)
												{
											LCD_DisplayChar(125,200,buf[0]);
														LCD_DisplayChar(140,200,buf[1]);
														LCD_DisplayChar(155,200,buf[2]);
												}
												if(finalLevel3Time2>=1000 && finalLevel3Time2<10000)
												{
													LCD_DisplayChar(125,200,buf[0]);
																LCD_DisplayChar(140,2000,buf[1]);
																LCD_DisplayChar(155,200,buf[2]);
																LCD_DisplayChar(170,200,buf[3]);
												}
												if(finalLevel3Time2>=10000)
												{
													LCD_DisplayChar(125,200,buf[0]);
																	LCD_DisplayChar(140,200,buf[1]);
																	LCD_DisplayChar(155,200,buf[2]);
																	LCD_DisplayChar(170,200,buf[3]);
																	LCD_DisplayChar(185,200,buf[4]);
												}

							}

				if(finalLevel3Time3<=finalLevel3Time && finalLevel3Time3<=finalLevel3Time2 )
										{
								itoa(finalLevel3Time3,buf,10);
											if(finalLevel3Time3<1000)
															{
														LCD_DisplayChar(125,200,buf[0]);
																	LCD_DisplayChar(140,200,buf[1]);
																	LCD_DisplayChar(155,200,buf[2]);
															}
															if(finalLevel3Time3>=1000 && finalLevel3Time3<10000)
															{
																LCD_DisplayChar(125,200,buf[0]);
																			LCD_DisplayChar(140,200,buf[1]);
																			LCD_DisplayChar(155,200,buf[2]);
																			LCD_DisplayChar(170,200,buf[3]);
															}
															if(finalLevel3Time3>=10000)
															{
																LCD_DisplayChar(125,180,buf[0]);
																				LCD_DisplayChar(140,200,buf[1]);
																				LCD_DisplayChar(155,200,buf[2]);
																				LCD_DisplayChar(170,200,buf[3]);
																				LCD_DisplayChar(185,200,buf[4]);
															}

										}






}



void EXTI0_IRQHandler(){

	IRQ_Disable_Int(EXTI0_IRQ_NUMBER);
	getFinalTime=HAL_GetTick();
		getFinalTime2=HAL_GetTick();
		flag=1;
		flag2=1;
		flagbackup=3;
	EXTI_Clear_Int(EXTI0_IRQ_NUMBER);
	IRQ_Enable_Int(EXTI0_IRQ_NUMBER);


}





