/*
 * Button_Driver.c
 *
 *  Created on: Sep 26, 2023
 *      Author: eliasharo
 */

//#include <stdio.h>
//#include <stdint.h>
#include "Button_Driver.h"
#include "stm32f4xx_hal.h"


void enable_Clock()
{
	__HAL_RCC_GPIOA_CLK_ENABLE (); //think this is error
}

bool button_Press_State()
{
	if (HAL_GPIO_ReadPin(BUTTON_PORT_VALUE, BUTTON_PIN_NUMBER)==BUTTON_PRESSED){ //MIGHT BE WRONG
		return true;
	}
	else
	{
		return false;
	}
}

void init_Button()
{
	enable_Clock();
	//HAL_GPIO_Init(BUTTON_PORT_VALUE,&button);
	GPIO_InitTypeDef button = {0};
	button.Pin=GPIO_PIN_0 ;
	button.Mode= GPIO_MODE_INPUT;
	HAL_GPIO_Init(BUTTON_PORT_VALUE,&button);
//	buttonConfig.GPIO_PinConfig.PinNumber=GPIO_pin0;
//	buttonConfig.GPIO_PinConfig.PinMode= INPUT;
//	buttonConfig.pGPIOx=GPIOA;
	//GPIO_initConfig(&buttonConfig);



}

void initButtonInterrupt(){
	 enable_Clock();
	 GPIO_InitTypeDef button = {0};
	 button.Pin=GPIO_PIN_0;
	 button.Mode=GPIO_MODE_IT_RISING_FALLING;
	 HAL_GPIO_Init(BUTTON_PORT_VALUE,&button);
//	buttonConfig.GPIO_PinConfig.PinNumber = GPIO_pin0;
//	buttonConfig.GPIO_PinConfig.PinMode = INPUT;
	//buttonConfig.pGPIOx = GPIOA;
	//buttonConfig.GPIO_PinConfig.PinInterruptMode = FALLINGANDRISINGINTERRUPT;
	//GPIO_initConfig(&buttonConfig);
	 IRQ_Enable_Int(EXTI0_IRQn); //EXTIO0_IRQ_NUMBER
}


