/*
 * Scheduler.c
 *
 *  Created on: Sep 7, 2023
 *      Author: eliasharo
 */


//#include <stdio.h>
//#include <stdint.h>
#include "Scheduler.h"

static uint32_t scheduledEvents;
void addSchedulerEvent(uint32_t event){
	scheduledEvents|=event;

}

void removeSchedulerEvent(uint32_t remEvent){
	scheduledEvents &= ~(remEvent);
}

uint32_t  getScheduledEvents() //getscheduled
{
	return scheduledEvents;
}

