/*
 * Gyro.c
 *
 *  Created on: Nov 7, 2023
 *      Author: eliasharo
 */
#include "Gyro.h"
#include <stdio.h>
extern void initialise_monitor_handles(void);


SPI_HandleTypeDef spi5gyro;
static HAL_StatusTypeDef gyroHALStatus;

void GYRO_init()
{
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_SPI5_CLK_ENABLE();

	GPIO_InitTypeDef gyro={0};
	gyro.Pin= SPI5SCK | SPI5MISO| SPI5MOSI; //check
	gyro.Speed= GPIO_SPEED_LOW;
	gyro.Pull= GPIO_NOPULL;
	gyro.Mode= GPIO_MODE_AF_PP;
	gyro.Alternate= GPIO_AF5_SPI5;
	HAL_GPIO_Init(SPI5_PORT, &gyro); //check this line

	gyro.Pin=NCS_MEMS_SP1;
	gyro.Pull= GPIO_PULLUP;
	gyro.Mode= GPIO_MODE_OUTPUT_OD;
	gyro.Speed= GPIO_SPEED_LOW;
	gyro.Alternate= 0;
	HAL_GPIO_Init(NCS_MEMS_SPI, &gyro);


	spi5gyro.Instance = SPI5;
	spi5gyro.Init.Mode = SPI_MODE_MASTER;
	spi5gyro.Init.Direction = SPI_DIRECTION_2LINES;
	spi5gyro.Init.DataSize = SPI_DATASIZE_8BIT;
	spi5gyro.Init.CLKPolarity = SPI_POLARITY_HIGH;
	spi5gyro.Init.CLKPhase = SPI_PHASE_2EDGE;
	spi5gyro.Init.NSS = SPI_NSS_SOFT;
	spi5gyro.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
	spi5gyro.Init.FirstBit = SPI_FIRSTBIT_MSB;
	spi5gyro.Init.TIMode = SPI_TIMODE_DISABLE;
	spi5gyro.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	spi5gyro.Init.CRCPolynomial = 0;
	//gyroHALStatus = HAL_SPI_Init(&spi5gyro);
	HAL_SPI_Init(&spi5gyro);

	if(gyroHALStatus!= HAL_OK){
		while (1);
	}
}




void GYRO_enableslave()
{
	HAL_GPIO_WritePin(NCS_MEMS_SPI, NCS_MEMS_SP1,GPIO_PIN_RESET);
}

void GYRO_disableslave()
{
	HAL_GPIO_WritePin(NCS_MEMS_SPI, NCS_MEMS_SP1,GPIO_PIN_SET);
}


void GYRO_deviceID()
{
	uint8_t commandToSend = (I3G4250D_READ |WHO_AM_I );
	uint16_t receivedData = 0x00;
	GYRO_enableslave();
	while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_1) != GPIO_PIN_RESET);

	gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToSend,(uint8_t*) &receivedData, 2,20000);

	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}

	uint16_t DataReturned = (0xFF00 & receivedData) >> 8; // Shift the data to get the bytes we want
	printf("The DataReturned is: %d \n", DataReturned);
	GYRO_disableslave();
}

void GYRO_power()
{
	uint8_t commandToSend = (I3G4250D_READ |CTRL_REG1 );
	uint16_t receivedData = 0x00;
	GYRO_enableslave();
	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);

	gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToSend, (uint8_t*)&receivedData, 2,20000);
	//HAL_StatusTypeDef gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToSend,(uint8_t*) &receivedData, 2,20000);
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}

	uint16_t DataReturned = (0xFF00 & receivedData) >> 8; // Shift the data to get the bytes we want
	uint8_t commandToSend2 = (WRITE |CTRL_REG1 )|((DataReturned | (1<<3))<<8);

	gyroHALStatus = HAL_SPI_Transmit(&spi5gyro, &commandToSend2, 2,20000);

	GYRO_disableslave();
	//WRITE
}


void GYRO_reboot()
{


	uint8_t commandToSend = (I3G4250D_READ |CTRL_REG5 );
		uint16_t receivedData = 0x00;
		GYRO_enableslave();
		while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);

		gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToSend, (uint8_t*)&receivedData, 2,20000);

		if(gyroHALStatus != HAL_OK)
		{
		for(;;); // Infinite Loop to catch errors
		}


		uint16_t DataReturned = (0xFF00 & receivedData) >> 8;
		uint8_t commandToSend2 = (WRITE |CTRL_REG1 )|((DataReturned | (1<<7))<<8);

		gyroHALStatus = HAL_SPI_Transmit(&spi5gyro, &commandToSend2, 2,20000);

		printf("The device will reboot \n");
		GYRO_disableslave();
}

void GYRO_temp()
{
	uint8_t commandToSend = (I3G4250D_READ | OUT_TEMP );
	uint16_t receivedData = 0x00;

	GYRO_enableslave();
	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
	gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToSend, (uint8_t*)&receivedData, 2,20000);
	if(gyroHALStatus != HAL_OK)
	{
		for(;;); // Infinite Loop to catch errors
	}
	uint16_t DataReturned = (0xFF00 & receivedData) >> 8;
	printf("The Temperature returned is: %d \n", DataReturned);
	GYRO_disableslave();



}

void GYRO_configreg()
{
	uint16_t commandToCR1 = (WRITE |CTRL_REG1) | (0x0F <<8);
	GYRO_enableslave();
	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
	gyroHALStatus = HAL_SPI_Transmit(&spi5gyro, (uint8_t*) &commandToCR1, 2,20000);
	GYRO_disableslave();
	if(gyroHALStatus != HAL_OK)
		{
			for(;;); // Infinite Loop to catch errors
		}

	uint16_t commandToCR4 = (WRITE |CTRL_REG4) | (0x10 <<8);
		GYRO_enableslave();
		while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
		gyroHALStatus = HAL_SPI_Transmit(&spi5gyro, (uint8_t*) &commandToCR4, 2,20000);
		GYRO_disableslave();
		if(gyroHALStatus != HAL_OK)
			{
				for(;;); // Infinite Loop to catch errors
			}

		uint16_t commandToCR5 = (WRITE |CTRL_REG5) | (0xC0 <<8);
				GYRO_enableslave();
				while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
				gyroHALStatus = HAL_SPI_Transmit(&spi5gyro, (uint8_t*) &commandToCR5, 2,20000);
				GYRO_disableslave();
				if(gyroHALStatus != HAL_OK)
					{
						for(;;); // Infinite Loop to catch errors
					}

		uint16_t commandToFIFO = (WRITE |FIFO_CTRL_REG) | (0x40 <<8);
				GYRO_enableslave();
				while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
				gyroHALStatus = HAL_SPI_Transmit(&spi5gyro, (uint8_t*) &commandToFIFO, 2,20000);
				GYRO_disableslave();
				if(gyroHALStatus != HAL_OK)
					{
						for(;;); // Infinite Loop to catch errors
					}




}


void GYRO_axis()
{
	uint8_t commandToXL = (WRITE |OUT_X_L );
	uint16_t receivedData = 0x00;
		GYRO_enableslave();
		while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
		gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToXL,(uint8_t*) &receivedData, 2,20000);
		//GYRO_disableslave();
		if(gyroHALStatus != HAL_OK)
		{
			for(;;); // Infinite Loop to catch errors
		}
		uint16_t DataReturned = (0xFF00 & receivedData) >> 8;
			printf("The Low X axis value is: %d \n", DataReturned);
			GYRO_disableslave();



	uint8_t commandToXH = (I3G4250D_READ |OUT_X_H );
	uint16_t receivedData2 = 0x00;
			GYRO_enableslave();
			while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
			gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToXH,(uint8_t*) &receivedData2, 2,20000);
			//GYRO_disableslave();
			if(gyroHALStatus != HAL_OK)
			{
				for(;;); // Infinite Loop to catch errors
			}
			uint16_t DataReturned2 = (0xFF00 & receivedData2) >> 8;
				printf("The High X axis value is: %d \n", DataReturned2);
				GYRO_disableslave();





	uint8_t commandToYL = (I3G4250D_READ |OUT_Y_L );
	uint16_t receivedData3 = 0x00;
		GYRO_enableslave();
		while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
		gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToYL,(uint8_t*) &receivedData3, 2,20000);
		//GYRO_disableslave();
		if(gyroHALStatus != HAL_OK)
		{
				for(;;); // Infinite Loop to catch errors
		}
		uint16_t DataReturned3 = (0xFF00 & receivedData3) >> 8;
			printf("The Low Y axis value is: %d \n", DataReturned3);
			GYRO_disableslave();




	uint8_t commandToYH = (I3G4250D_READ |OUT_Y_H );
	uint16_t receivedData4 = 0x00;
			GYRO_enableslave();
			while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
			gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToYH,(uint8_t*) &receivedData4, 2,20000);
			//GYRO_disableslave();
			if(gyroHALStatus != HAL_OK)
			{
				for(;;); // Infinite Loop to catch errors
			}
			uint16_t DataReturned4 = (0xFF00 & receivedData4) >> 8;
				printf("The High Y axis value is: %d \n", DataReturned4);
				GYRO_disableslave();

		uint8_t commandToZL = (I3G4250D_READ |OUT_Z_L );
		uint16_t receivedData5 = 0x00;
			GYRO_enableslave();
			while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
			gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToZL,(uint8_t*) &receivedData5, 2,20000);
			//GYRO_disableslave();
			if(gyroHALStatus != HAL_OK)
			{
				for(;;); // Infinite Loop to catch errors
			}
			uint16_t DataReturned5 = (0xFF00 & receivedData5) >> 8;
				printf("The Low Z axis value is: %d \n", DataReturned5);
				GYRO_disableslave();

		uint8_t commandToZH = (I3G4250D_READ |OUT_Z_H );
		uint16_t receivedData6 = 0x00;
			GYRO_enableslave();
			while(HAL_GPIO_ReadPin(NCS_MEMS_SPI,NCS_MEMS_SP1) != GPIO_PIN_RESET);
			gyroHALStatus = HAL_SPI_TransmitReceive(&spi5gyro, &commandToZH,(uint8_t*) &receivedData6, 2,20000);
			//GYRO_disableslave();
			if(gyroHALStatus != HAL_OK)
			{
				for(;;); // Infinite Loop to catch errors
			}
			uint16_t DataReturned6 = (0xFF00 & receivedData6) >> 8;
				printf("The High Z axis value is: %d \n", DataReturned6);
				GYRO_disableslave();



}





