/*
 * LED_Driver.c
 *
 *  Created on: Sep 7, 2023
 *      Author: eliasharo
 */



#include "LED_Driver.h"



static GPIO_InitTypeDef redLED;
//
static GPIO_InitTypeDef greenLED;

void init_LED(uint8_t led){
	switch(led){
	case RED:
		redLED.Pin=GPIO_PIN_14;
		redLED.Mode=GPIO_MODE_OUTPUT_PP;
		redLED.Speed=GPIO_SPEED_LOW;
		redLED.Pull=GPIO_NOPULL;
		HAL_GPIO_Init(GPIOG,&redLED);


//		redLED.pGPIOx=GPIOG;
//		redLED.GPIO_PinConfig.PinNumber = pin14;
//		redLED.GPIO_PinConfig.PinMode = GP_OUTPUT; ;
//		redLED.GPIO_PinConfig.PinSpeed = LOW_SPEED;
//		redLED.GPIO_PinConfig.OPType = PUSH_PULL;
//		redLED.GPIO_PinConfig.PinPuPdControl = NOPULLUP_DOWN;
//		GPIO_clock(GPIOG,ENABLE);
		//GPIO_initConfig(&redLED);//& accesses the address
		break;
	case GREEN:
		greenLED.Pin=GPIO_PIN_13;
		greenLED.Mode=GPIO_MODE_OUTPUT_PP;
		greenLED.Speed=GPIO_SPEED_LOW;
		greenLED.Pull=GPIO_NOPULL;
		HAL_GPIO_Init(GPIOG,&greenLED);
//		greenLED.pGPIOx=GPIOG;
//		greenLED.GPIO_PinConfig.PinNumber = pin13;
//		greenLED.GPIO_PinConfig.PinMode = GP_OUTPUT; ;
//		greenLED.GPIO_PinConfig.PinSpeed = LOW_SPEED;
//		greenLED.GPIO_PinConfig.OPType = PUSH_PULL;
//		greenLED.GPIO_PinConfig.PinPuPdControl = NOPULLUP_DOWN;
//		GPIO_clock(GPIOG,ENABLE);
//		GPIO_initConfig(&greenLED);
		break;
		//GPIO_PinConfig_t ledInit()
	default:
		break;


	}
}

	void tog_LED(uint8_t led){
	switch(led){
	case RED:
		HAL_GPIO_TogglePin(GPIOG,GPIO_PIN_14);
		break;
	case GREEN:
		HAL_GPIO_TogglePin(GPIOG,GPIO_PIN_13 );
		break;
	default:
		break;
	}
}


void disable_LED(uint8_t led){ //make sure the _ is correct
	switch(led){
	case RED:
		HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_RESET);
		//GPIO_writePinval(GPIOG, GPIO_PIN_14, DISABLE);
	case GREEN:
		HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_RESET);
		//GPIO_writePinval(GPIOG,GPIO_PIN_13  , DISABLE);
	}
}
void enable_LED(uint8_t led){
	switch(led){
	case RED:
		HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_SET);
		//GPIO_writePinval(GPIOG,GPIO_PIN_14, ENABLE);
		break;
	case GREEN:
		HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_SET);
		//GPIO_writePinval(GPIOG,GPIO_PIN_13,ENABLE);
		break;
	default:
		break;
	}

}

void enableClock(uint8_t led){
	__HAL_RCC_GPIOG_CLK_ENABLE ();
	// GPIO_clock(GPIOG, ENABLE);
}

