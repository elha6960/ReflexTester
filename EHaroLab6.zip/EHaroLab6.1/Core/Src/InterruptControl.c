/*
 * InterruptControl.c
 *
 *  Created on: Oct 4, 2023
 *      Author: eliasharo
 */


#include "InterruptControl.h"
#include "stm32f429xx.h"

void IRQ_Enable_Int(uint8_t IRQ_Number)
{
	if(IRQ_Number <32)
	{
		*NVIC_ISER0 |= (1 << IRQ_Number);
	}
	else{
		*NVIC_ISER0 |= (1 << (IRQ_Number % 32));
	}
}


void IRQ_Disable_Int(uint8_t IRQ_Number)
{
	if(IRQ_Number <32)
	{
		*NVIC_ICER0 |= (1 << IRQ_Number);
	}
	else{
		*NVIC_ICER0 |= (1 << (IRQ_Number % 32));
	}
}

void IRQ_Clear_Pending_Int(uint8_t IRQ_Number)
{
	if(IRQ_Number <32)
		{
			*NVIC_ISPR0 |= (1 << IRQ_Number);
		}
		else{
			*NVIC_ISPR0 |= (1 << (IRQ_Number % 32));
		}
}


void IRQ_Set_Pending_Int(uint8_t IRQ_Number)
{
	if(IRQ_Number <32)
		{
			*NVIC_ICPR0 |= (1 << IRQ_Number);
		}
		else{
			*NVIC_ICPR0 |= (1 << (IRQ_Number % 32));
		}
}

void EXTI_Clear_Int(uint8_t pin_number)
{
	//_//HAL_GPIO_EXTI_CLEAR_IT();
	EXTI ->PR |= (1<< pin_number); //check why we have to set
}
