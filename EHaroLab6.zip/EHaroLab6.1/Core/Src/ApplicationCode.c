/*
 * ApplicationCode.c
 *
 *  Created on: Nov 14, 2023
 *      Author: xcowa
 */

#include "ApplicationCode.h"




void ApplicationInit(void)
{
	LTCD__Init();
	 RNG_init();
    LTCD_Layer_Init(0);
    LCD_Clear(0,LCD_COLOR_WHITE);

    initButtonInterrupt();


    addSchedulerEvent(INTRO_EVENT);
    addSchedulerEvent(FIRST_EVENT);
    addSchedulerEvent(SECOND_EVENT);
    addSchedulerEvent(THIRD_EVENT );
    addSchedulerEvent(FINAL_EVENT );

}


void intro()
{
	 introScreen();
}
void firstlev()
{
	  Level_1();
}
void secondlev()
{
	   Level_2();
}
void thirdlev()
{
	 Level_3();
}
void results()
{
	  resultsScreen();
}

void RunDemoForLCD(void)
{
	QuickDemo();
}
