/*
 * RNG.c
 *
 *  Created on: Nov 28, 2023
 *      Author: eliasharo
 */

#include "stdint.h"
#include "RNG.h"



RNG_HandleTypeDef rng={0};


void RNG_init(){
	__HAL_RCC_RNG_CLK_ENABLE();
	rng.Instance =RNG;
	HAL_RNG_Init(&rng);
}

uint32_t RNG_recieve(uint32_t maxVal, uint32_t minVal)
{
	 maxVal=100;
	 minVal=1;

	uint32_t numbergenerated;
    HAL_RNG_GenerateRandomNumber(&rng, &numbergenerated);
    uint32_t numberToBeUsed= ((numbergenerated % (maxVal-minVal))+minVal);
    return numberToBeUsed;
}

