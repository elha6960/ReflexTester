/*
 * ErrorHandlingFileset.c
 *
 *  Created on: Nov 7, 2023
 *      Author: eliasharo
 */
#include "ErrorHandlingFileset.h"

void APPLICATIONASSERT(bool assert)
{
	if (assert == false)
	{
		while(1); //check
	}
}
